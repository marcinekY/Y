-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Czas wygenerowania: 21 Sie 2012, 07:21
-- Wersja serwera: 5.5.16
-- Wersja PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Baza danych: `y.cms`
--

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `asset`
--

CREATE TABLE IF NOT EXISTS `asset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `item_type` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `parent_type` varchar(60) COLLATE utf8_polish_ci DEFAULT NULL,
  `name` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `value` text COLLATE utf8_polish_ci NOT NULL,
  `type` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=4 ;

--
-- Zrzut danych tabeli `asset`
--

INSERT INTO `asset` (`id`, `item_id`, `item_type`, `parent_id`, `parent_type`, `name`, `value`, `type`) VALUES
(1, 1, 'site', NULL, NULL, '', '{"extensions":{"smarty":{"config":{"left_delimiter":"{{","right_delimiter":"}}","caching":true,"cache_dir":"y.admin\\/cache\\/admin"}}}}', ''),
(2, 1, 'extend', NULL, NULL, '', '{"config":{"left_delimiter":"{{","right_delimiter":"}}","caching":false,"compile_dir":"cache\\/compile\\/"}}', ''),
(3, 1, 'extend', 2, 'template', '', '{"config":{"caching":false,"compile_dir":"y.admin\\/cache\\/template__admin_defult\\/compile\\/","cache_dir":"y.admin\\/cache\\/template__admin_defult\\/"}}', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `level` smallint(6) DEFAULT '0',
  `name` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `alias` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `type` varchar(20) COLLATE utf8_polish_ci DEFAULT 'page',
  `title` varchar(60) COLLATE utf8_polish_ci DEFAULT NULL,
  `hits` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `contents`
--

CREATE TABLE IF NOT EXISTS `contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `wid_id` int(11) DEFAULT NULL,
  `sec_id` int(11) DEFAULT NULL,
  `value` text COLLATE utf8_polish_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_content_widgets` (`wid_id`),
  KEY `FK_sections_contents` (`sec_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=3 ;

--
-- Zrzut danych tabeli `contents`
--

INSERT INTO `contents` (`id`, `name`, `wid_id`, `sec_id`, `value`) VALUES
(1, 'header', NULL, 1, 'testowy content'),
(2, 'body', NULL, 2, '<p>body<p>');

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `extends`
--

CREATE TABLE IF NOT EXISTS `extends` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `description` text COLLATE utf8_polish_ci,
  `type` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `path` varchar(255) COLLATE utf8_polish_ci NOT NULL,
  `version` smallint(6) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=4 ;

--
-- Zrzut danych tabeli `extends`
--

INSERT INTO `extends` (`id`, `name`, `description`, `type`, `path`, `version`) VALUES
(1, 'smarty', 'System szablonów smarty', 'parser-tamplate', 'smarty/', 1),
(2, 'menus', 'Plugin menu', 'html-generator', 'menus/', 1),
(3, 'meta-builder', 'Generuje sekcje head', 'html-generator', 'meta-builder/', 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `extends_groups`
--

CREATE TABLE IF NOT EXISTS `extends_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ext_id` int(11) NOT NULL,
  `gro_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_extends_eg` (`ext_id`),
  KEY `FK_groups_eg` (`gro_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `extends_sites`
--

CREATE TABLE IF NOT EXISTS `extends_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ext_id` int(11) NOT NULL,
  `sit_id` int(11) NOT NULL,
  `enabled` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_extends_es` (`ext_id`),
  KEY `FK_sites_es` (`sit_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=4 ;

--
-- Zrzut danych tabeli `extends_sites`
--

INSERT INTO `extends_sites` (`id`, `ext_id`, `sit_id`, `enabled`) VALUES
(1, 1, 1, 1),
(2, 2, 1, 1),
(3, 3, 1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `extends_templates`
--

CREATE TABLE IF NOT EXISTS `extends_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ext_id` int(11) NOT NULL,
  `tem_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_extends_et` (`ext_id`),
  KEY `FK_templates_et` (`tem_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=3 ;

--
-- Zrzut danych tabeli `extends_templates`
--

INSERT INTO `extends_templates` (`id`, `ext_id`, `tem_id`) VALUES
(1, 1, 2),
(2, 2, 2);

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) COLLATE utf8_polish_ci NOT NULL,
  `description` text COLLATE utf8_polish_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=3 ;

--
-- Zrzut danych tabeli `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, '_superadmininistrator', NULL),
(2, '_adminministrator', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sit_id` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `tem_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `alias` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_polish_ci NOT NULL,
  `introtext` text COLLATE utf8_polish_ci,
  `special` int(11) NOT NULL DEFAULT '0',
  `type` varchar(64) COLLATE utf8_polish_ci NOT NULL DEFAULT '0',
  `ord` int(11) DEFAULT NULL,
  `cdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `edate` datetime DEFAULT NULL,
  `associated_date` datetime DEFAULT NULL,
  `hits` int(11) DEFAULT '0',
  `published` smallint(6) DEFAULT NULL,
  `access` smallint(6) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `FK_categories_pages` (`cat_id`),
  KEY `FK_sites_pages` (`sit_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=3 ;

--
-- Zrzut danych tabeli `pages`
--

INSERT INTO `pages` (`id`, `sit_id`, `cat_id`, `tem_id`, `parent_id`, `alias`, `title`, `introtext`, `special`, `type`, `ord`, `cdate`, `edate`, `associated_date`, `hits`, `published`, `access`) VALUES
(1, 1, NULL, 1, NULL, 'home', 'Strona główna', 'page', 1, '0', NULL, '2012-08-17 16:37:50', NULL, NULL, 0, 1, 0),
(2, 1, NULL, NULL, NULL, 'login', 'Strona logowania', 'page', 0, '0', NULL, '2012-08-17 16:37:50', NULL, NULL, 0, NULL, 0);

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `pages_contents`
--

CREATE TABLE IF NOT EXISTS `pages_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pag_id` int(11) NOT NULL,
  `con_id` int(11) NOT NULL,
  `ord` int(11) DEFAULT NULL,
  `published` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_contents_pc` (`con_id`),
  KEY `FK_pages_pc` (`pag_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=3 ;

--
-- Zrzut danych tabeli `pages_contents`
--

INSERT INTO `pages_contents` (`id`, `pag_id`, `con_id`, `ord`, `published`) VALUES
(1, 2, 1, NULL, 1),
(2, 2, 2, NULL, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sections`
--

CREATE TABLE IF NOT EXISTS `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `tem_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `ord` int(11) DEFAULT NULL,
  `type` varchar(64) COLLATE utf8_polish_ci NOT NULL,
  `enabled` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_templates_sections` (`tem_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=3 ;

--
-- Zrzut danych tabeli `sections`
--

INSERT INTO `sections` (`id`, `name`, `tem_id`, `parent_id`, `ord`, `type`, `enabled`) VALUES
(1, 'index', 2, NULL, NULL, 'html', 1),
(2, 'header', 2, 1, NULL, 'html', NULL);

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `sites`
--

CREATE TABLE IF NOT EXISTS `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tem_id` int(11) NOT NULL,
  `name` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `url` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `cdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `path` varchar(155) COLLATE utf8_polish_ci NOT NULL,
  `type` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=3 ;

--
-- Zrzut danych tabeli `sites`
--

INSERT INTO `sites` (`id`, `tem_id`, `name`, `url`, `cdate`, `path`, `type`) VALUES
(1, 2, 'admin', 'y.admin/', '2012-08-17 16:37:50', 'y.admin/', 'admin'),
(2, 1, 'test', '/', '2012-08-17 16:37:50', '/', 'site');

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `templates`
--

CREATE TABLE IF NOT EXISTS `templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `title` varchar(60) COLLATE utf8_polish_ci DEFAULT NULL,
  `description` text COLLATE utf8_polish_ci,
  `path` text COLLATE utf8_polish_ci NOT NULL,
  `type` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=3 ;

--
-- Zrzut danych tabeli `templates`
--

INSERT INTO `templates` (`id`, `name`, `title`, `description`, `path`, `type`) VALUES
(1, '_default', 'Standardowy szablon stron', 'Standardowy szablon stron', '_default/', ''),
(2, '_admin_defult', 'Szablon panelu administracji', 'Standardowy szablon panelu administracyjnego', '_default/', '');

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(24) COLLATE utf8_polish_ci NOT NULL,
  `email` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_polish_ci NOT NULL,
  `active` smallint(6) NOT NULL DEFAULT '0',
  `groups` text COLLATE utf8_polish_ci,
  `activation_key` varchar(32) COLLATE utf8_polish_ci NOT NULL,
  `extras` text COLLATE utf8_polish_ci,
  `last_ip` varchar(20) COLLATE utf8_polish_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=2 ;

--
-- Zrzut danych tabeli `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `active`, `groups`, `activation_key`, `extras`, `last_ip`, `last_login`, `added`) VALUES
(1, '', 'marcinbrodowski@gmail.com', 'e8095c46085419910f9fff746720f09b', 1, NULL, '', NULL, '127.0.0.1', '2012-07-21 15:36:35', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `users_groups`
--

CREATE TABLE IF NOT EXISTS `users_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gro_id` int(11) NOT NULL,
  `use_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_goups_ug` (`gro_id`),
  KEY `FK_users_ug` (`use_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=2 ;

--
-- Zrzut danych tabeli `users_groups`
--

INSERT INTO `users_groups` (`id`, `gro_id`, `use_id`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `users_sites`
--

CREATE TABLE IF NOT EXISTS `users_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sit_id` int(11) NOT NULL,
  `use_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FK_sites_us` (`sit_id`),
  KEY `FK_users_us` (`use_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=3 ;

--
-- Zrzut danych tabeli `users_sites`
--

INSERT INTO `users_sites` (`id`, `sit_id`, `use_id`) VALUES
(1, 1, 1),
(2, 2, 1);

-- --------------------------------------------------------

--
-- Struktura tabeli dla  `widgets`
--

CREATE TABLE IF NOT EXISTS `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(60) COLLATE utf8_polish_ci NOT NULL,
  `ext_id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `type` varchar(20) COLLATE utf8_polish_ci NOT NULL,
  `html` text COLLATE utf8_polish_ci,
  `path` text COLLATE utf8_polish_ci,
  PRIMARY KEY (`id`),
  KEY `FK_extends_widgets` (`ext_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_polish_ci AUTO_INCREMENT=1 ;

--
-- Ograniczenia dla zrzutów tabel
--

--
-- Ograniczenia dla tabeli `contents`
--
ALTER TABLE `contents`
  ADD CONSTRAINT `FK_content_widgets` FOREIGN KEY (`wid_id`) REFERENCES `widgets` (`id`),
  ADD CONSTRAINT `FK_sections_contents` FOREIGN KEY (`sec_id`) REFERENCES `sections` (`id`);

--
-- Ograniczenia dla tabeli `extends_groups`
--
ALTER TABLE `extends_groups`
  ADD CONSTRAINT `FK_extends_eg` FOREIGN KEY (`ext_id`) REFERENCES `extends` (`id`),
  ADD CONSTRAINT `FK_groups_eg` FOREIGN KEY (`gro_id`) REFERENCES `groups` (`id`);

--
-- Ograniczenia dla tabeli `extends_sites`
--
ALTER TABLE `extends_sites`
  ADD CONSTRAINT `FK_extends_es` FOREIGN KEY (`ext_id`) REFERENCES `extends` (`id`),
  ADD CONSTRAINT `FK_sites_es` FOREIGN KEY (`sit_id`) REFERENCES `sites` (`id`);

--
-- Ograniczenia dla tabeli `extends_templates`
--
ALTER TABLE `extends_templates`
  ADD CONSTRAINT `FK_extends_et` FOREIGN KEY (`ext_id`) REFERENCES `extends` (`id`),
  ADD CONSTRAINT `FK_templates_et` FOREIGN KEY (`tem_id`) REFERENCES `templates` (`id`);

--
-- Ograniczenia dla tabeli `pages`
--
ALTER TABLE `pages`
  ADD CONSTRAINT `FK_categories_pages` FOREIGN KEY (`cat_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `FK_sites_pages` FOREIGN KEY (`sit_id`) REFERENCES `sites` (`id`);

--
-- Ograniczenia dla tabeli `pages_contents`
--
ALTER TABLE `pages_contents`
  ADD CONSTRAINT `FK_contents_pc` FOREIGN KEY (`con_id`) REFERENCES `contents` (`id`),
  ADD CONSTRAINT `FK_pages_pc` FOREIGN KEY (`pag_id`) REFERENCES `pages` (`id`);

--
-- Ograniczenia dla tabeli `sections`
--
ALTER TABLE `sections`
  ADD CONSTRAINT `FK_templates_sections` FOREIGN KEY (`tem_id`) REFERENCES `templates` (`id`);

--
-- Ograniczenia dla tabeli `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `FK_goups_ug` FOREIGN KEY (`gro_id`) REFERENCES `groups` (`id`),
  ADD CONSTRAINT `FK_users_ug` FOREIGN KEY (`use_id`) REFERENCES `users` (`id`);

--
-- Ograniczenia dla tabeli `users_sites`
--
ALTER TABLE `users_sites`
  ADD CONSTRAINT `FK_sites_us` FOREIGN KEY (`sit_id`) REFERENCES `sites` (`id`),
  ADD CONSTRAINT `FK_users_us` FOREIGN KEY (`use_id`) REFERENCES `users` (`id`);

--
-- Ograniczenia dla tabeli `widgets`
--
ALTER TABLE `widgets`
  ADD CONSTRAINT `FK_extends_widgets` FOREIGN KEY (`ext_id`) REFERENCES `extends` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
